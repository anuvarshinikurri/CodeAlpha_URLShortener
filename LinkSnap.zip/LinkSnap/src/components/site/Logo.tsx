import { Link } from "@tanstack/react-router";
import { Link2 } from "lucide-react";

export function Logo() {
  return (
    <Link to="/" className="group flex items-center gap-2.5" aria-label="LinkSnap home">
      <span className="grid size-9 place-items-center rounded-xl bg-gradient-brand text-primary-foreground shadow-glow transition-transform duration-300 group-hover:rotate-[-8deg]">
        <Link2 className="size-5" strokeWidth={2.5} />
      </span>
      <span className="font-display text-lg font-bold tracking-tight text-foreground">
        Link<span className="text-gradient-brand">Snap</span>
      </span>
    </Link>
  );
}
