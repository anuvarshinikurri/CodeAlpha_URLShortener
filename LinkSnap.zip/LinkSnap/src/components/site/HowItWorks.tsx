const STEPS = [
  { title: "Enter your long URL", description: "Paste any http or https link into the box." },
  { title: "Click Shorten URL", description: "We check the address and send it to the server." },
  { title: "Get your unique short link", description: "A fresh code is generated and saved for you." },
  { title: "Share and access it", description: "Anyone opening the short link lands on your page." },
];

export function HowItWorks() {
  return (
    <ol className="relative grid gap-5 md:grid-cols-4">
      <div className="pointer-events-none absolute left-[12%] right-[12%] top-7 hidden h-px bg-gradient-brand opacity-30 md:block" />
      {STEPS.map((step, i) => (
        <li key={step.title} className="relative flex flex-col items-center text-center">
          <span className="relative z-10 grid size-14 place-items-center rounded-2xl bg-gradient-brand font-display text-lg font-bold text-primary-foreground shadow-glow">
            {i + 1}
          </span>
          <h3 className="mt-4 text-base font-semibold text-foreground">{step.title}</h3>
          <p className="mt-1.5 max-w-[16rem] text-sm text-muted-foreground">{step.description}</p>
        </li>
      ))}
    </ol>
  );
}
