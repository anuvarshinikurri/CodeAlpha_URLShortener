import { format } from "date-fns";
import { AlertCircle, Copy, Link2, Loader2, RefreshCw, Trash2 } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useDeleteLink, useLinks } from "@/hooks/use-links";
import type { ShortLink } from "@/lib/api";
import { copyToClipboard } from "@/lib/clipboard";

function formatDate(iso: string) {
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? iso : format(d, "MMM d, yyyy · HH:mm");
}

function StatCard({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-5 shadow-card">
      <p className="text-sm text-muted-foreground">{label}</p>
      <p className="mt-1 font-display text-3xl font-bold text-gradient-brand">{value}</p>
    </div>
  );
}

function RowActions({ link }: { link: ShortLink }) {
  const remove = useDeleteLink();
  return (
    <div className="flex justify-end gap-1.5">
      <Button
        variant="soft"
        size="icon"
        aria-label={`Copy ${link.short_url}`}
        onClick={() => copyToClipboard(link.short_url)}
      >
        <Copy />
      </Button>
      <Button
        variant="ghost"
        size="icon"
        className="rounded-lg text-destructive hover:bg-destructive/10 hover:text-destructive"
        aria-label={`Delete ${link.short_url}`}
        disabled={remove.isPending}
        onClick={() =>
          remove.mutate(link.code, {
            onSuccess: () => toast.success("Link deleted"),
            onError: (err) => toast.error(err.message),
          })
        }
      >
        {remove.isPending ? <Loader2 className="animate-spin" /> : <Trash2 />}
      </Button>
    </div>
  );
}

export function Dashboard() {
  const { data, isPending, isError, error, refetch, isFetching } = useLinks();
  const urls = data?.urls ?? [];
  const totalClicks = urls.reduce((sum, u) => sum + (u.clicks ?? 0), 0);

  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard label="Total URLs created" value={isPending ? "—" : (data?.total ?? 0)} />
        <StatCard label="Total clicks" value={isPending ? "—" : totalClicks} />
        <StatCard
          label="Latest link"
          value={urls[0] ? format(new Date(urls[0].created_at), "MMM d") : "—"}
        />
      </div>

      <div className="overflow-hidden rounded-2xl border border-border bg-card shadow-card">
        <div className="flex items-center justify-between border-b border-border px-5 py-4">
          <h3 className="font-semibold text-foreground">Your links</h3>
          <Button
            variant="ghost"
            size="sm"
            className="rounded-lg"
            onClick={() => refetch()}
            disabled={isFetching}
          >
            <RefreshCw className={isFetching ? "animate-spin" : ""} /> Refresh
          </Button>
        </div>

        {isPending ? (
          <div className="space-y-3 p-5">
            {[0, 1, 2].map((i) => (
              <Skeleton key={i} className="h-12 w-full rounded-xl" />
            ))}
          </div>
        ) : isError ? (
          <div className="flex flex-col items-center gap-3 px-5 py-12 text-center">
            <AlertCircle className="size-8 text-destructive" />
            <p className="max-w-md text-sm text-muted-foreground">{error.message}</p>
            <Button variant="outline" className="rounded-xl" onClick={() => refetch()}>
              Try again
            </Button>
          </div>
        ) : urls.length === 0 ? (
          <div className="flex flex-col items-center gap-3 px-5 py-14 text-center">
            <span className="grid size-12 place-items-center rounded-2xl bg-accent text-accent-foreground">
              <Link2 className="size-5" />
            </span>
            <p className="font-medium text-foreground">No links yet</p>
            <p className="text-sm text-muted-foreground">
              Shorten your first URL above and it will show up here.
            </p>
          </div>
        ) : (
          <>
            {/* Desktop table */}
            <div className="hidden overflow-x-auto md:block">
              <table className="w-full text-sm">
                <thead className="bg-muted/60 text-left text-xs uppercase tracking-wider text-muted-foreground">
                  <tr>
                    <th className="px-5 py-3 font-semibold">Original URL</th>
                    <th className="px-5 py-3 font-semibold">Short URL</th>
                    <th className="px-5 py-3 font-semibold">Clicks</th>
                    <th className="px-5 py-3 font-semibold">Created</th>
                    <th className="px-5 py-3 text-right font-semibold">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {urls.map((link) => (
                    <tr key={link.code} className="transition-colors hover:bg-muted/40">
                      <td className="max-w-[18rem] truncate px-5 py-3.5 text-foreground" title={link.original_url}>
                        {link.original_url}
                      </td>
                      <td className="px-5 py-3.5">
                        <a
                          href={link.short_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="font-medium text-primary hover:underline"
                        >
                          {link.short_url.replace(/^https?:\/\//, "")}
                        </a>
                      </td>
                      <td className="px-5 py-3.5 text-muted-foreground">{link.clicks}</td>
                      <td className="whitespace-nowrap px-5 py-3.5 text-muted-foreground">
                        {formatDate(link.created_at)}
                      </td>
                      <td className="px-5 py-3.5">
                        <RowActions link={link} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Mobile cards */}
            <ul className="divide-y divide-border md:hidden">
              {urls.map((link) => (
                <li key={link.code} className="space-y-2 px-5 py-4">
                  <a
                    href={link.short_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block truncate font-medium text-primary"
                  >
                    {link.short_url.replace(/^https?:\/\//, "")}
                  </a>
                  <p className="truncate text-sm text-muted-foreground">{link.original_url}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">
                      {formatDate(link.created_at)} · {link.clicks} clicks
                    </span>
                    <RowActions link={link} />
                  </div>
                </li>
              ))}
            </ul>
          </>
        )}
      </div>
    </div>
  );
}
