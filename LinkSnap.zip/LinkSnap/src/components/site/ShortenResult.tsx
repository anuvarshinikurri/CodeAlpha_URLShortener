import { CheckCircle2, Copy, ExternalLink } from "lucide-react";

import { Button } from "@/components/ui/button";
import type { ShortLink } from "@/lib/api";
import { copyToClipboard } from "@/lib/clipboard";

export function ShortenResult({ link }: { link: ShortLink }) {
  return (
    <div
      key={link.code}
      className="animate-fade-up mt-6 overflow-hidden rounded-2xl border border-border bg-card text-left shadow-card"
    >
      <div className="flex items-center gap-2 border-b border-border bg-success/10 px-5 py-3 text-sm font-medium text-success">
        <CheckCircle2 className="size-4" /> Your short link is ready
      </div>
      <div className="space-y-4 p-5">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
            Original URL
          </p>
          <p className="mt-1 truncate text-sm text-foreground" title={link.original_url}>
            {link.original_url}
          </p>
        </div>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div className="min-w-0">
            <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              Short URL
            </p>
            <a
              href={link.short_url}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-1 block truncate font-display text-xl font-semibold text-gradient-brand"
            >
              {link.short_url}
            </a>
          </div>
          <div className="flex shrink-0 gap-2">
            <Button variant="hero" className="h-10 px-4" onClick={() => copyToClipboard(link.short_url)}>
              <Copy /> Copy
            </Button>
            <Button asChild variant="outline" className="h-10 rounded-xl px-4">
              <a href={link.short_url} target="_blank" rel="noopener noreferrer">
                <ExternalLink /> Open
              </a>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
