import { useState, type FormEvent } from "react";
import { AlertCircle, ArrowRight, Link2, Loader2 } from "lucide-react";

import { Button } from "@/components/ui/button";
import { useShortenLink } from "@/hooks/use-links";
import type { ShortLink } from "@/lib/api";
import { validateUrl } from "@/lib/url-validation";
import { ShortenResult } from "./ShortenResult";

export function ShortenForm() {
  const [value, setValue] = useState("");
  const [validationError, setValidationError] = useState<string | null>(null);
  const [result, setResult] = useState<ShortLink | null>(null);
  const shorten = useShortenLink();

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    const check = validateUrl(value);
    if (!check.ok) {
      setValidationError(check.error);
      return;
    }
    setValidationError(null);
    shorten.mutate(check.url, {
      onSuccess: (link) => {
        setResult(link);
        setValue("");
      },
    });
  };

  const error = validationError ?? (shorten.isError ? shorten.error.message : null);

  return (
    <div className="mx-auto w-full max-w-3xl">
      <form
        onSubmit={onSubmit}
        noValidate
        className="flex flex-col gap-2 rounded-2xl border border-border bg-card p-2 shadow-card transition-shadow focus-within:border-primary/40 focus-within:shadow-glow sm:flex-row"
      >
        <label htmlFor="long-url" className="sr-only">
          Long URL
        </label>
        <div className="flex flex-1 items-center gap-3 px-3">
          <Link2 className="size-5 shrink-0 text-muted-foreground" />
          <input
            id="long-url"
            type="url"
            inputMode="url"
            autoComplete="off"
            placeholder="Paste your long URL here…"
            value={value}
            onChange={(e) => {
              setValue(e.target.value);
              if (validationError) setValidationError(null);
            }}
            aria-invalid={!!error}
            aria-describedby={error ? "url-error" : undefined}
            className="h-12 w-full min-w-0 bg-transparent text-base text-foreground outline-none placeholder:text-muted-foreground sm:h-14"
          />
        </div>
        <Button type="submit" variant="hero" size="xl" disabled={shorten.isPending}>
          {shorten.isPending ? (
            <>
              <Loader2 className="animate-spin" /> Shortening…
            </>
          ) : (
            <>
              Shorten URL <ArrowRight />
            </>
          )}
        </Button>
      </form>

      {error && (
        <p
          id="url-error"
          role="alert"
          className="animate-fade-up mt-3 flex items-start gap-2 rounded-xl bg-destructive/10 px-4 py-3 text-left text-sm text-destructive"
        >
          <AlertCircle className="mt-0.5 size-4 shrink-0" />
          {error}
        </p>
      )}

      {result && <ShortenResult link={result} />}
    </div>
  );
}
