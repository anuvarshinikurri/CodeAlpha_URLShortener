import { Database, Fingerprint, LayoutDashboard, Rocket, Zap } from "lucide-react";

export const FEATURES = [
  {
    icon: Zap,
    title: "Fast URL shortening",
    description: "Paste a link and get a short version back in a fraction of a second.",
  },
  {
    icon: Fingerprint,
    title: "Unique short links",
    description: "Every link gets its own random 6-character code, checked for collisions.",
  },
  {
    icon: Rocket,
    title: "Instant redirection",
    description: "Visitors who open your short link are sent straight to the original page.",
  },
  {
    icon: Database,
    title: "Reliable URL storage",
    description: "Links are saved in a database so they keep working long after you create them.",
  },
  {
    icon: LayoutDashboard,
    title: "Easy link management",
    description: "See every link you've made, copy it again, or delete it from the dashboard.",
  },
] as const;

export function FeatureGrid() {
  return (
    <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
      {FEATURES.map(({ icon: Icon, title, description }, i) => (
        <div
          key={title}
          className="group relative overflow-hidden rounded-2xl border border-border bg-card p-6 shadow-card transition-all duration-300 hover:-translate-y-1 hover:border-primary/30"
          style={{ animationDelay: `${i * 70}ms` }}
        >
          <div className="pointer-events-none absolute -right-10 -top-10 size-32 rounded-full bg-gradient-brand opacity-0 blur-2xl transition-opacity duration-500 group-hover:opacity-20" />
          <span className="grid size-11 place-items-center rounded-xl bg-accent text-accent-foreground transition-colors group-hover:bg-gradient-brand group-hover:text-primary-foreground">
            <Icon className="size-5" />
          </span>
          <h3 className="mt-5 text-lg font-semibold text-foreground">{title}</h3>
          <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{description}</p>
        </div>
      ))}
    </div>
  );
}
