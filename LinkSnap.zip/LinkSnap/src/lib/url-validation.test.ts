import { describe, expect, it } from "vitest";

import { validateUrl } from "./url-validation";

describe("validateUrl", () => {
  it("accepts a full https URL unchanged", () => {
    expect(validateUrl("https://example.com/path?q=1")).toEqual({
      ok: true,
      url: "https://example.com/path?q=1",
    });
  });

  it("adds https:// to a bare domain", () => {
    expect(validateUrl("example.com/page")).toEqual({ ok: true, url: "https://example.com/page" });
  });

  it("rejects an empty value", () => {
    expect(validateUrl("   ").ok).toBe(false);
  });

  it("rejects text that is not a web address", () => {
    expect(validateUrl("hello world").ok).toBe(false);
  });

  it("rejects non-http schemes", () => {
    expect(validateUrl("ftp://example.com/file").ok).toBe(false);
  });

  it("rejects URLs longer than 2048 characters", () => {
    expect(validateUrl(`https://example.com/${"a".repeat(2050)}`).ok).toBe(false);
  });
});
