import { z } from "zod";

export const MAX_URL_LENGTH = 2048;

/** Adds https:// when the user typed a bare domain like "example.com/page". */
export function normalizeUrl(input: string): string {
  const trimmed = input.trim();
  if (!trimmed) return trimmed;
  return /^[a-z][a-z\d+\-.]*:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
}

export const urlSchema = z
  .string()
  .trim()
  .min(1, { message: "Please paste a URL to shorten." })
  .max(MAX_URL_LENGTH, { message: `URLs must be under ${MAX_URL_LENGTH} characters.` })
  .transform(normalizeUrl)
  .refine(
    (value) => {
      if (/\s/.test(value)) return false;
      try {
        const parsed = new URL(value);
        return (
          (parsed.protocol === "http:" || parsed.protocol === "https:") &&
          parsed.hostname.includes(".") &&
          !parsed.hostname.startsWith(".") &&
          !parsed.hostname.endsWith(".")
        );
      } catch {
        return false;
      }
    },
    { message: "That doesn't look like a valid web address. Try something like https://example.com" },
  );

export type UrlValidationResult = { ok: true; url: string } | { ok: false; error: string };

export function validateUrl(input: string): UrlValidationResult {
  const result = urlSchema.safeParse(input);
  if (result.success) return { ok: true, url: result.data };
  return { ok: false, error: result.error.issues[0]?.message ?? "Invalid URL." };
}
