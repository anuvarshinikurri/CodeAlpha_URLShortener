import { toast } from "sonner";

export async function copyToClipboard(text: string) {
  try {
    await navigator.clipboard.writeText(text);
    toast.success("Link copied to clipboard", { description: text });
    return true;
  } catch {
    toast.error("Couldn't copy the link. Please copy it manually.");
    return false;
  }
}
