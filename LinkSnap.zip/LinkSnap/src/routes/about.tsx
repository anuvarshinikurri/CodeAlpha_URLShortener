import { createFileRoute } from "@tanstack/react-router";
import { Code2, Database, Server } from "lucide-react";

import { SectionHeading } from "@/components/site/SectionHeading";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — LinkSnap" },
      {
        name: "description",
        content: "LinkSnap is a URL shortener built for the CodeAlpha Backend Development Internship.",
      },
      { property: "og:title", content: "About — LinkSnap" },
      {
        property: "og:description",
        content: "LinkSnap is a URL shortener built for the CodeAlpha Backend Development Internship.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AboutPage,
});

const STACK = [
  { icon: Server, title: "Python Flask API", text: "A REST API creates short codes, stores links and handles redirects." },
  { icon: Database, title: "SQLite storage", text: "Each link is saved with its original URL, code, date and click count." },
  { icon: Code2, title: "Modern web app", text: "A responsive interface that talks to the API for every action." },
];

function AboutPage() {
  return (
    <div className="relative">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-96 bg-gradient-soft" />
      <section className="relative mx-auto max-w-4xl px-4 py-20 sm:px-6">
        <SectionHeading
          eyebrow="About"
          title={<>Why <span className="text-gradient-brand">LinkSnap</span>?</>}
        />
        <div className="mx-auto mt-8 max-w-2xl space-y-4 text-center text-base leading-relaxed text-muted-foreground">
          <p>
            Long links are hard to read, easy to break and awkward to share. LinkSnap turns them into
            short, tidy links you can drop into messages, posts and slides.
          </p>
          <p>
            It was developed as part of the <strong className="text-foreground">CodeAlpha Backend
            Development Internship</strong> to show how a real backend generates, stores and resolves
            short links.
          </p>
        </div>
        <div className="mt-14 grid gap-5 sm:grid-cols-3">
          {STACK.map(({ icon: Icon, title, text }) => (
            <div
              key={title}
              className="rounded-2xl border border-border bg-card p-6 shadow-card transition-transform duration-300 hover:-translate-y-1"
            >
              <span className="grid size-11 place-items-center rounded-xl bg-gradient-brand text-primary-foreground shadow-glow">
                <Icon className="size-5" />
              </span>
              <h3 className="mt-5 font-semibold text-foreground">{title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{text}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
