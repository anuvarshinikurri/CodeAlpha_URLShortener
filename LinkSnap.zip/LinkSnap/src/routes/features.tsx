import { createFileRoute, Link } from "@tanstack/react-router";

import { FeatureGrid } from "@/components/site/FeatureGrid";
import { HowItWorks } from "@/components/site/HowItWorks";
import { SectionHeading } from "@/components/site/SectionHeading";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/features")({
  head: () => ({
    meta: [
      { title: "Features — LinkSnap" },
      {
        name: "description",
        content: "Fast shortening, unique codes, instant redirects, reliable storage and easy link management.",
      },
      { property: "og:title", content: "Features — LinkSnap" },
      {
        property: "og:description",
        content: "Fast shortening, unique codes, instant redirects, reliable storage and easy link management.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: FeaturesPage,
});

function FeaturesPage() {
  return (
    <div className="relative">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-96 bg-gradient-soft" />
      <section className="relative mx-auto max-w-6xl px-4 py-20 sm:px-6">
        <SectionHeading
          eyebrow="Features"
          title={<>Built for <span className="text-gradient-brand">speed and simplicity</span></>}
          description="A focused set of tools that turn messy links into clean, shareable ones."
        />
        <div className="mt-14">
          <FeatureGrid />
        </div>
      </section>
      <section className="bg-muted/60 py-20">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <SectionHeading eyebrow="How it works" title="From long to short in seconds" />
          <div className="mt-14">
            <HowItWorks />
          </div>
          <div className="mt-14 text-center">
            <Button asChild variant="hero" size="xl">
              <Link to="/">Shorten a link now</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
