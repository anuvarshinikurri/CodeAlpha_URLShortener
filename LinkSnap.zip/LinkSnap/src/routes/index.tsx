import { createFileRoute } from "@tanstack/react-router";
import { ShieldCheck, Sparkles, Zap } from "lucide-react";

import { Dashboard } from "@/components/site/Dashboard";
import { FeatureGrid } from "@/components/site/FeatureGrid";
import { HowItWorks } from "@/components/site/HowItWorks";
import { SectionHeading } from "@/components/site/SectionHeading";
import { ShortenForm } from "@/components/site/ShortenForm";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "LinkSnap — Shorten Your Links. Simplify Your Sharing." },
      {
        name: "description",
        content: "Transform long URLs into short, easy-to-share links in seconds with LinkSnap.",
      },
      { property: "og:title", content: "LinkSnap — Shorten Your Links. Simplify Your Sharing." },
      {
        property: "og:description",
        content: "Transform long URLs into short, easy-to-share links in seconds with LinkSnap.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <>
      <section className="relative overflow-hidden">
        <div className="pointer-events-none absolute inset-0 bg-gradient-soft" />
        <div className="pointer-events-none absolute inset-0 bg-grid" />
        <div className="relative mx-auto max-w-6xl px-4 pb-20 pt-16 text-center sm:px-6 sm:pt-24">
          <span className="animate-fade-up inline-flex items-center gap-2 rounded-full border border-border bg-card/80 px-4 py-1.5 text-xs font-semibold text-accent-foreground shadow-card backdrop-blur">
            <Sparkles className="size-3.5" /> Free, fast & reliable link shortener
          </span>
          <h1
            className="animate-fade-up mx-auto mt-6 max-w-4xl text-4xl font-extrabold leading-[1.08] text-foreground sm:text-6xl"
            style={{ animationDelay: "80ms" }}
          >
            Shorten Your Links. <span className="text-gradient-brand">Simplify Your Sharing.</span>
          </h1>
          <p
            className="animate-fade-up mx-auto mt-5 max-w-xl text-base text-muted-foreground sm:text-lg"
            style={{ animationDelay: "160ms" }}
          >
            Transform long URLs into short, easy-to-share links in seconds.
          </p>
          <div className="animate-fade-up mt-10" style={{ animationDelay: "240ms" }}>
            <ShortenForm />
          </div>
          <div className="mt-8 flex flex-wrap justify-center gap-x-6 gap-y-2 text-sm text-muted-foreground">
            <span className="flex items-center gap-1.5"><Zap className="size-4 text-primary" /> Instant results</span>
            <span className="flex items-center gap-1.5"><ShieldCheck className="size-4 text-primary" /> Validated links</span>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-20 sm:px-6">
        <SectionHeading
          eyebrow="Features"
          title="Everything you need to share smarter"
          description="LinkSnap keeps things simple: short links that are quick to make and always work."
        />
        <div className="mt-12">
          <FeatureGrid />
        </div>
      </section>

      <section className="bg-muted/60 py-20">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <SectionHeading eyebrow="How it works" title="Four steps to a shorter link" />
          <div className="mt-14">
            <HowItWorks />
          </div>
        </div>
      </section>

      <section id="dashboard" className="mx-auto max-w-6xl scroll-mt-20 px-4 py-20 sm:px-6">
        <SectionHeading
          eyebrow="Dashboard"
          title="Manage your links"
          description="Every link you shorten is saved here. Copy it again or remove it anytime."
        />
        <div className="mt-12">
          <Dashboard />
        </div>
      </section>
    </>
  );
}
