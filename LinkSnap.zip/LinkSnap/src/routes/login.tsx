import { useState, type FormEvent } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";

import { Logo } from "@/components/site/Logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Login — LinkSnap" },
      { name: "description", content: "Sign in to LinkSnap to manage your short links." },
      { property: "og:title", content: "Login — LinkSnap" },
      { property: "og:description", content: "Sign in to LinkSnap to manage your short links." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: LoginPage,
});

function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    toast.info("Accounts are coming soon", {
      description: "You can shorten and manage links without signing in.",
    });
  };

  return (
    <div className="relative">
      <div className="pointer-events-none absolute inset-0 bg-gradient-soft" />
      <section className="relative mx-auto flex max-w-md flex-col px-4 py-20">
        <div className="animate-fade-up rounded-3xl border border-border bg-card p-8 shadow-card">
          <div className="flex justify-center">
            <Logo />
          </div>
          <h1 className="mt-6 text-center text-2xl font-bold text-foreground">Welcome back</h1>
          <p className="mt-1 text-center text-sm text-muted-foreground">Sign in to manage your links</p>
          <form onSubmit={onSubmit} className="mt-8 space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                required
                maxLength={255}
                placeholder="you@example.com"
                className="h-11 rounded-xl"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                required
                maxLength={128}
                placeholder="••••••••"
                className="h-11 rounded-xl"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
            <Button type="submit" variant="hero" className="h-11 w-full">
              Sign in
            </Button>
          </form>
          <p className="mt-6 text-center text-sm text-muted-foreground">
            Just want a short link?{" "}
            <Link to="/" className="font-medium text-primary hover:underline">
              Go to the shortener
            </Link>
          </p>
        </div>
      </section>
    </div>
  );
}
